 <footer class="bg-secondary text-bg-dark text-center text-lg-start">
     <!-- Copyright -->
     <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.05);">
         © 2024 Copyright
         <a class="text-warning text-decoration-none" href="https://github.com/MuhammadBobby">Muhammad Bobby</a>
     </div>
     <!-- Copyright -->
 </footer>
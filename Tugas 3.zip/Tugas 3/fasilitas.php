<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Fasilitas Universitas</title>

  <!-- css bootstrap -->
  <link rel="stylesheet" href="css/bootstrap.css" />
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Universitas XYZ</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="index.php">Jurusan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="formPendaftaran.php">Form Calon Mahasiswa</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="fasilitas.php">Fasilitas</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- end navbar -->

  <!-- fasilitas -->
  <div class="container my-5">
    <h1>Fasilitas Universitas XYZ</h1>
    <div class="row">
      <div class="col-md-4">
        <div class="card bg-primary text-white">
          <div class="card-body">
            <h5 class="card-title">Fasilitas 1</h5>
            <p class="card-text">Deskripsi fasilitas 1</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card bg-danger text-white">
          <div class="card-body">
            <h5 class="card-title">Fasilitas 2</h5>
            <p class="card-text">Deskripsi fasilitas 2</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card bg-warning text-white">
          <div class="card-body">
            <h5 class="card-title">Fasilitas 3</h5>
            <p class="card-text">Deskripsi fasilitas 3</p>
          </div>
        </div>
      </div>
      <div class="col-md-6 mt-2">
        <div class="card bg-secondary text-white">
          <div class="card-body">
            <h5 class="card-title">Fasilitas 4</h5>
            <p class="card-text">Deskripsi fasilitas 4</p>
          </div>
        </div>
      </div>
      <div class="col-md-6 mt-2">
        <div class="card bg-success text-white">
          <div class="card-body">
            <h5 class="card-title">Fasilitas 3</h5>
            <p class="card-text">Deskripsi fasilitas 3</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>
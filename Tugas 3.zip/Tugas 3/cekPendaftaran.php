<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Form Pendaftaran Calon Mahasiswa Baru</title>

    <!-- css bootstrap -->
    <link rel="stylesheet" href="css/bootstrap.css" />
</head>

<body>
    <div class="container my-5">
        <div class="card">
            <div class="card-header">
                <h3>Detail Pendaftaran</h3>
            </div>
            <div class="card-body">
                <?php
                if (isset($_POST["submit"])) {
                    $nama = htmlspecialchars($_POST['nama']);
                    $email = htmlspecialchars($_POST['email']);
                    $telepon = htmlspecialchars($_POST['telepon']);
                    $tempatLahir = htmlspecialchars($_POST['tempatLahir']);
                    $tglLahir = htmlspecialchars($_POST['tglLahir']);
                    $jenkel = htmlspecialchars($_POST['jenkel']);
                    $alamat = htmlspecialchars($_POST['alamat']);
                    $kota = htmlspecialchars($_POST['kota']);
                    $provinsi = htmlspecialchars($_POST['provinsi']);
                    $kodepos = htmlspecialchars($_POST['kodepos']);
                    $jurusan = htmlspecialchars($_POST['jurusan']);
                    $prodi = htmlspecialchars($_POST['prodi']);
                    $asalsklh = htmlspecialchars($_POST['asalsklh']);
                    $nilai = htmlspecialchars($_POST['nilai']);
                    $ortu = htmlspecialchars($_POST['ortu']);
                    $motivasi = htmlspecialchars($_POST['motivasi']);

                    echo "<h5>Nama: $nama</h5>";
                    echo "<p><strong>Email:</strong> $email</p>";
                    echo "<p><strong>No. Telepon:</strong> $telepon</p>";
                    echo "<p><strong>Tempat Lahir:</strong> $tempatLahir</p>";
                    echo "<p><strong>Tanggal Lahir:</strong> $tglLahir</p>";
                    echo "<p><strong>Jenis Kelamin:</strong> $jenkel</p>";
                    echo "<p><strong>Alamat:</strong> $alamat</p>";
                    echo "<p><strong>Kota:</strong> $kota</p>";
                    echo "<p><strong>Provinsi:</strong> $provinsi</p>";
                    echo "<p><strong>Kode Pos:</strong> $kodepos</p>";
                    echo "<p><strong>Jurusan:</strong> $jurusan</p>";
                    echo "<p><strong>Prodi:</strong> $prodi</p>";
                    echo "<p><strong>Asal Sekolah:</strong> $asalsklh</p>";
                    echo "<p><strong>Nilai Rata-rata:</strong> $nilai</p>";
                    echo "<p><strong>Nama Orang Tua:</strong> $ortu</p>";
                    echo "<p><strong>Motivasi Masuk Universitas:</strong> $motivasi</p>";
                } else {
                    echo "<p>Tidak ada data yang dikirim</p>";
                }
                ?>
            </div>
        </div>
    </div>

</body>

</html>
document.querySelector("form").addEventListener("submit", function (event) {
  let isValid = true;

  // Validasi Nama
  const nama = document.getElementById("nama").value;
  if (nama === "") {
    alert("Nama harus diisi");
    isValid = false;
  }

  // Validasi Email
  const email = document.getElementById("email").value;
  const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  if (!emailPattern.test(email)) {
    alert("Email tidak valid");
    isValid = false;
  }

  // Validasi Telepon
  const telepon = document.getElementById("telepon").value;
  if (telepon === "" || isNaN(telepon) || telepon.length < 10) {
    alert("No. Telepon harus diisi dan terdiri dari angka minimal 10 digit");
    isValid = false;
  }

  // Validasi Tanggal Lahir
  const tglLahir = document.getElementById("tglLahir").value;
  if (tglLahir === "") {
    alert("Tanggal Lahir harus diisi");
    isValid = false;
  }

  // Validasi Jenis Kelamin
  const jenkel = document.querySelector('input[name="jenkel"]:checked');
  if (!jenkel) {
    alert("Jenis Kelamin harus dipilih");
    isValid = false;
  }

  // Validasi Alamat
  const alamat = document.getElementById("alamat").value;
  if (alamat === "") {
    alert("Alamat harus diisi");
    isValid = false;
  }

  // Validasi Kota
  const kota = document.getElementById("kota").value;
  if (kota === "") {
    alert("Kota harus diisi");
    isValid = false;
  }

  // Validasi Provinsi
  const provinsi = document.getElementById("provinsi").value;
  if (provinsi === "") {
    alert("Provinsi harus diisi");
    isValid = false;
  }

  // Validasi Kode Pos
  const kodepos = document.getElementById("kodepos").value;
  if (kodepos === "" || isNaN(kodepos) || kodepos.length < 5) {
    alert("Kode Pos harus diisi dan terdiri dari angka minimal 5 digit");
    isValid = false;
  }

  // Validasi Jurusan
  const jurusan = document.getElementById("jurusan").value;
  if (jurusan === "--Pilih Jurusan--") {
    alert("Jurusan harus dipilih");
    isValid = false;
  }

  // Validasi Prodi
  const prodi = document.getElementById("prodi").value;
  if (prodi === "") {
    alert("Prodi harus diisi");
    isValid = false;
  }

  // Validasi Asal Sekolah
  const asalsklh = document.getElementById("asalsklh").value;
  if (asalsklh === "") {
    alert("Asal Sekolah harus diisi");
    isValid = false;
  }

  // Validasi Nilai
  const nilai = document.getElementById("nilai").value;
  if (nilai === "" || isNaN(nilai) || nilai < 0 || nilai > 100) {
    alert("Nilai Rata-rata harus diisi dan antara 0-100");
    isValid = false;
  }

  // Validasi Orang Tua
  const ortu = document.getElementById("ortu").value;
  if (ortu === "") {
    alert("Nama Orang Tua harus diisi");
    isValid = false;
  }

  // Validasi Motivasi
  const motivasi = document.getElementById("motivasi").value;
  if (motivasi === "") {
    alert("Motivasi harus diisi");
    isValid = false;
  }

  if (!isValid) {
    event.preventDefault();
  }

  if (isValid) {
    alert("Pendaftaran berhasil dilakukan. Terimakasih telah mengisi form ini.");
  }
});

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pertemuan 3 | Tugas</title>

  <!-- css bootstrap -->
  <link rel="stylesheet" href="css/bootstrap.css" />
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Universitas XYZ</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Jurusan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="formPendaftaran.php">Form Calon Mahasiswa</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="fasilitas.php">Fasilitas</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- end navbar -->

  <!-- jurusan -->
  <div class="container mt-5">
    <h1>Jurusan Universitas XYZ</h1>
    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Kode Jurusan</th>
          <th scope="col">Nama Jurusan</th>
          <th scope="col">Deskripsi</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">1</th>
          <td>01010</td>
          <td>Teknik Komputer & Informatika</td>
          <td>jurusan teknik komputer informatika memiliki total 4 program studi</td>
        </tr>
        <tr>
          <th scope="row">2</th>
          <td>01020</td>
          <td>Teknik Mesin</td>
          <td>jurusan teknik mesin memiliki total 4 program studi</td>
        </tr>
        <tr>
          <th scope="row">3</th>
          <td>01030</td>
          <td>Teknik Sipil</td>
          <td>jurusan teknik sipil memiliki total 4 program studi</td>
        </tr>
      </tbody>
    </table>
  </div>
  <!-- end jurusan -->
</body>

</html>
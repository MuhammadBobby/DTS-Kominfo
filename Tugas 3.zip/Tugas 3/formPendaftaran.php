<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Form Pendaftaran Calon Mahasiswa Baru</title>

  <!-- css bootstrap -->
  <link rel="stylesheet" href="css/bootstrap.css" />
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Universitas XYZ</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="index.php">Jurusan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="formPendaftaran.php">Form Calon Mahasiswa</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="fasilitas.php">Fasilitas</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- end navbar -->

  <!-- form -->
  <div class="container my-5">
    <h1>Form Pendaftaran</h1>
    <div class="mt-3 bg-body-tertiary p-3 rounded">
      <form class="row g-3" action="cekPendaftaran.php" method="POST">
        <div class="col-md-12">
          <label for="nama" class="form-label fw-bold">Nama</label>
          <input type="text" class="form-control" id="nama" name="nama" placeholder="John" />
        </div>
        <div class="col-12">
          <label for="email" class="form-label">Email</label>
          <input type="email" class="form-control" id="email" name="email" placeholder="example@gmail.com" />
        </div>
        <div class="col-12">
          <label for="telepon" class="form-label">No. Telepon</label>
          <input type="number" class="form-control" id="telepon" name="telepon" placeholder="08xxxxxxx" />
        </div>
        <div class="col-md-8">
          <label for="tempatLahir" class="form-label">Tempat Lahir</label>
          <input type="text" class="form-control" id="tempatLahir" name="tempatLahir" placeholder="Medan" />
        </div>
        <div class="col-md-4">
          <label for="tglLahir" class="form-label">Tgl. Lahir</label>
          <input type="date" class="form-control" id="tglLahir" name="tglLahir" />
        </div>
        <div class="col-12">
          <label for="jenkel" class="form-label">Jenis Kelamin</label>
          <br />
          <input type="radio" name="jenkel" id="laki-laki" value="laki-laki" />
          <label for="laki-laki">laki-laki</label>
          <input type="radio" name="jenkel" id="perempuan" value="perempuan" />
          <label for="perempuan">perempuan</label>
        </div>
        <div class="col-12">
          <label for="alamat" class="form-label">Alamat</label>
          <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Jalan. xxxx" />
        </div>
        <div class="col-12">
          <label for="kota" class="form-label">Kota</label>
          <input type="text" class="form-control" id="kota" name="kota" placeholder="Medan" />
        </div>
        <div class="col-12">
          <label for="provinsi" class="form-label">Provinsi</label>
          <input type="text" class="form-control" id="provinsi" name="provinsi" placeholder="Sumatera Utara" />
        </div>
        <div class="col-12">
          <label for="kodepos" class="form-label">Kode Pos</label>
          <input type="number" class="form-control" id="kodepos" name="kodepos" placeholder="12345" />
        </div>
        <div class="col-md-4">
          <label for="jurusan" class="form-label">Jurusan</label>
          <select id="jurusan" name="jurusan" class="form-select">
            <option selected>--Pilih Jurusan--</option>
            <option value="Teknik Komputer & Informatika">Teknik Komputer & Informatika</option>
            <option value="Teknik Mesin">Teknik Sipil</option>
            <option value="Teknik Mesin">Teknik Mesin</option>
          </select>
        </div>
        <div class="col-md-6">
          <label for="prodi" class="form-label">Prodi</label>
          <input type="text" class="form-control" id="prodi" name="prodi" />
        </div>

        <div class="col-md-8">
          <label for="asalsklh" class="form-label">Asal Sekolah</label>
          <input type="text" class="form-control" id="asalsklh" name="asalsklh" placeholder="SMK XYZ" />
        </div>
        <div class="col-md-4">
          <label for="nilai" class="form-label">Nilai Rata Rata</label>
          <input type="number" class="form-control" id="nilai" name="nilai" placeholder="--" min="0" max="100" />
        </div>
        <div class="col-md-4">
          <label for="ortu" class="form-label">Nama Orang Tua</label>
          <input type="text" class="form-control" id="ortu" name="ortu" placeholder="Budi" />
        </div>
        <div class="col-12">
          <label for="motivasi" class="form-label">Motivasi masuk univeristas</label>
          <textarea name="motivasi" class="form-control" id="motivasi"></textarea>
        </div>

        <div class="col-12">
          <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  </div>

  <script src="js/validasi.js"></script>
</body>

</html>